package com.example.calc;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    EditText investedAmount, dividendRate;
    AutoCompleteTextView months;
    Button calculateButton, clearButton;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        investedAmount = findViewById(R.id.investedAmount);
        dividendRate = findViewById(R.id.dividendRate);
        months = findViewById(R.id.months);
        calculateButton = findViewById(R.id.calculateButton);
        clearButton = findViewById(R.id.clearButton);
        result = findViewById(R.id.result);

        // Setup months dropdown
        String[] monthsArray = new String[12];
        for (int i = 0; i < 12; i++) monthsArray[i] = String.valueOf(i + 1);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, monthsArray);
        months.setAdapter(adapter);
        months.setOnClickListener(v -> months.showDropDown());

        calculateButton.setOnClickListener(v -> {
            String investedStr = investedAmount.getText().toString().trim();
            String dividendStr = dividendRate.getText().toString().trim();
            String monthsStr = months.getText().toString().trim();

            if (investedStr.isEmpty() || dividendStr.isEmpty() || monthsStr.isEmpty()) {
                result.setText("Please fill in all fields correctly.");
                return;
            }

            try {
                double amount = Double.parseDouble(investedStr);
                double rate = Double.parseDouble(dividendStr);
                int month = Integer.parseInt(monthsStr);

                if (month < 1 || month > 12) {
                    result.setText("Months invested must be between 1 and 12.");
                    return;
                }
                if (amount <= 0) {
                    result.setText("Invested amount must be greater than 0.");
                    return;
                }
                if (rate <= 0) {
                    result.setText("Annual dividend rate must be greater than 0.");
                    return;
                }

                double monthlyDividend = (rate / 100 / 12) * amount;
                double totalDividend = monthlyDividend * month;

                result.setText(String.format("📈 Monthly Dividend: RM %.2f\n💰 Total Dividend: RM %.2f", monthlyDividend, totalDividend));
            } catch (NumberFormatException e) {
                result.setText("Please enter valid numeric values.");
            }
        });


        clearButton.setOnClickListener(v -> {
            investedAmount.setText("");
            dividendRate.setText("");
            months.setText("");
            result.setText("Monthly :\n\n\nTotal :");
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.home) {
            return true; // already in home
        } else if (id == R.id.about) {
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
