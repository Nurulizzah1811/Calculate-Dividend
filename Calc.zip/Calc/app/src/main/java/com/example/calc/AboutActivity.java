package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.pm.PackageManager;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("About");
        }

        TextView versionText = findViewById(R.id.versionText);
        try {
            String version = getPackageManager()
                    .getPackageInfo(getPackageName(), 0).versionName;
            versionText.setText("App Version: " + version);
        } catch (PackageManager.NameNotFoundException e) {
            versionText.setText("App Version: Unknown");
        }

        // Email click
        LinearLayout emailLayout = findViewById(R.id.emailLayout);
        emailLayout.setOnClickListener(v -> {
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
            emailIntent.setData(Uri.parse("mailto:your.email@example.com"));
            startActivity(emailIntent);
        });

        // Phone click
        LinearLayout phoneLayout = findViewById(R.id.phoneLayout);
        phoneLayout.setOnClickListener(v -> {
            Intent phoneIntent = new Intent(Intent.ACTION_DIAL);
            phoneIntent.setData(Uri.parse("tel:+60123456789"));
            startActivity(phoneIntent);
        });

        LinearLayout websiteLayout = findViewById(R.id.websiteLayout);
        websiteLayout.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/Nurulizzah1811/Calculate-Dividend"));
            startActivity(browserIntent);
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
